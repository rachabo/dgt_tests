These are taken from the geograph.org.uk source code. There is no documentation
except for the code.

http://svn.geograph.org.uk/svn/trunk/libs/geograph/conversions.class.php
http://svn.geograph.org.uk/svn/trunk/libs/geograph/conversionslatlong.class.php
